---
triggers:
  phrases:
    - "set up ugc creator programme"
    - "personalize ugc creator programme"
    - "reconfigure ugc creator programme"
    - "set up the creator programme app"
    - "add creators to the app"
    - "populate the creator programme"
  intent: "User wants to configure or populate the ugc-creator-programme app for their brand"
---

# Skill: setup-ugc-creator-programme

Guides the user through populating the creator programme app for their specific brand. One question at a time. Writes directly to `/agent/brain/ugc-creator-programme/creators.json` after each answer.

---

## When to use

- Automatically after install (final post-install step)
- Any time the user wants to add, update or reconfigure creators in the app
- When the user wants to populate VIP relationships, ambassador programme data, or sourcing targets

---

## What this writes to

All answers write to: `/agent/brain/ugc-creator-programme/creators.json`

The app reads from this file on every page load. Changes take effect immediately — no rebuild required.

---

## Execution

### Step 1 — Brand name and subtitle

Ask:
> "What's your brand name? This appears in the app header."

After answer, write `brandName` in the JSON.

Then:
> "What's the one-line subtitle for the app? This sits under the brand name in green. Something like 'One Cup Closer to the right creator' — or whatever fits your brief."

Write `brandSubtitle`.

---

### Step 2 — Personas

Ask:
> "Does the default list of audience personas work for your brand, or do you want to rename or replace them?
>
> Current defaults:
> - Strava Millennial
> - Sporty Dad
> - Active Mum
> - Trail Runner
> - 55–65 Sharp
> - Weekend Golfer
> - Dog Walker
> - UGC Creator
>
> Say 'keep them' or tell me which ones to change."

If changes requested, update the `personas` map in the JSON. Persona keys become filter values in the app — keep them as simple lowercase strings.

---

### Step 3 — Selection criteria

Ask:
> "Do the creator selection criteria match how you evaluate creators? These appear at the top of the sourcing tab.
>
> The defaults are based on Meta ad performance data: 2-second hook rule, personal language, experience-first, social proof distance, real settings, UK-based.
>
> Say 'keep them' or tell me what to change."

Update `selectionCriteria` array if changes requested. Each item has `main` (bold) and `sub` (supporting detail).

---

### Step 4 — VIP relationships

Ask:
> "Who are the key people you already have direct access to — investors, brand partners, or existing commercial relationships?
>
> For each person give me: name, Instagram/TikTok handle, their role (investor / brand partner / ambassador), which product they should promote (AM / PM / both), urgency (urgent / normal / low), and the brief angle that makes most sense for them."

For each person provided, add to `vipCreators` array. If they have urgency `urgent`, also set `urgencyNote` with specific deadline or context.

After each VIP is added, ask if there are more before moving on.

---

### Step 5 — Ambassador programme

Ask:
> "Do you have an existing ambassador programme? If yes, I can add those creators here so the team can see brief recommendations and discount codes all in one place.
>
> For each ambassador give me: name, handle, niche, follower count, discount code, how much content they've posted, when they were last active, and any notes about them."

Add each to `ambassadors` array. If they've posted content, `contentCount` is something like `2 Reels + 3 Stories`. If not, use `No content yet`.

Also ask:
> "Are there any priority callouts to show at the top of the ambassador section? For example: 'Adam has 150K followers and hasn't posted yet — chase now.'"

Add to `priorityCallouts` array as plain strings.

---

### Step 6 — Creator sourcing list

Ask:
> "Do you have a list of creators you want to source? I can add them to the sourcing tab with persona tags, tier ratings, video confidence, outreach DMs, and brief angles.
>
> You can:
> a) Add them now one by one
> b) Share a list and I'll format them
> c) Skip for now — you can add them later by asking me to add a creator to the programme"

If they add creators now, for each one collect:
- name, platform handles + URLs
- audience persona (use a key from the personas map)
- tier (1, 2, or 3)
- follower count
- engagement signal (key fact about them)
- estimated rate
- video confidence (confirmed / likely / verify)
- video evidence (what you know about their on-camera style)
- why they fit the brand
- best brief angle
- any caveats
- outreach DM (the first message to send them)

If the DM starts with `N/A —`, the card shows it as a platform sourcing note rather than a copyable DM.

---

### Step 7 — Confirm and rebuild

After all data is written, confirm:
> "Creator programme is populated. Here's a summary:
> - [N] VIP relationships
> - [N] active ambassadors
> - [N] sourcing targets
> - [N] urgent briefs flagged
>
> The app is reading live from the JSON file — no rebuild needed. Open it to verify everything looks right."

Surface the app URL if available.

---

## How to add a single creator later

If the user says "add [name] to the creator programme" at any time:
1. Ask for the details (persona, tier, handles, followers, rate, video confidence, brief angle, DM)
2. Read the current JSON from `/agent/brain/ugc-creator-programme/creators.json`
3. Append to the `creators` array
4. Write the updated JSON back
5. Confirm: "Added [name] to the sourcing list. The app will show them immediately."

---

## Fallbacks

- If `creators.json` doesn't exist: create it from scratch using the template at `/agent/brain/ugc-creator-programme/creators.json`
- If the user wants to reset: overwrite the file with the blank template
- If the app returns a 404 on `/api/creators`: the JSON file is missing or was moved — re-run setup to restore it
